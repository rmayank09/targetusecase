package services;

/**
 * @author Mayank Kumar Rai
 */
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;


@Path("/")
public class CommentCheckService {
	
	@POST
	@Path("/checkComment")
	@Consumes(MediaType.TEXT_PLAIN)
	public Response checkCommentREST(String incomingData) {
	/* 
	 * Here we can follow two approaches to filter out abusive/profane content :
	 * 1st - Through Pattern Matching for specific words.
	 * 2nd - By checking the string for words from a already established collection of profane words.
	 */
		
	 //Initializing the list of profane words.
		
	 List<String> wordlist = new ArrayList<String>();
	 wordlist.add("abuse");
	 wordlist.add("batch");
	 wordlist.add("cuss");
	 wordlist.add("hateful");
		
	 // 1st Approach Starts Here.
	 
	 if (incomingData.matches(".*?\\bfork\\b.*?")) {
	    	  return Response.status(406).entity("Target Prohibits Use of Abusive Language !!!").build();
	 }else {
		    //2nd Approach starts here
	    	  for (int i = 0; i < wordlist.size(); i++)
	  		{
	  			if(incomingData.contains(wordlist.get(i)))
	  			{
	  				return Response.status(406).entity("Target Prohibits Use of Abusive Language !!!").build();
		  		}
	  			
	  		}
	    	// return HTTP response 200 in case of success
	  		return Response.status(200).entity("Comment complies with Target Ethics. Ok to be posted").build();
	      }
	}
	
	@GET
	@Path("/verify")
	@Produces(MediaType.TEXT_HTML)
	public Response verifyRESTService(InputStream incomingData) {
		String result = "CommentProfanityFilterService Successfully started..";
 
		// return HTTP response 200 in case of success
		return Response.status(200).entity(result).build();
	}

}
